<html>

<a href="form.html"> link to back to form </a>

</html> 
<?php

$dept = $_POST["Departments"];


$conn   = new mysqli("127.0.0.1:3306", "root","", "wpc");
$sql    = "SELECT firstname, lastname FROM employee WHERE Department='$dept'";
$result = $conn->query($sql);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "Employee Name: " . $row["firstname"] . " " . $row["lastname"] . "<br>";
    }
} else {
    echo "0 results";
}
mysqli_close($conn);

?> 