	<a href="form.html"> link to back to form </a>
	<a href="report.html"> link to back to report </a>
<?php

$DBConnect = mysqli_connect('127.0.0.1:3306', 'root','', 'wpc');
if (!$DBConnect){  
die('Could not connect; ' . mysqli_connect_error());
// investigate the function, die( ) 
 }
$sql = "SELECT * FROM PROJECT";
$result = mysqli_query($DBConnect,$sql);

echo "<table border= '1'>";
echo "<tr><td>ProjectId</td><td>ProjectName<td><td>Department<td>
<td>MaxHours<td><td>StartDate<td><td>EndDate</tr><td>";



while($row= mysqli_fetch_assoc($result)){
	echo "<tr><td>{$row['ProjectID']}</td><td>{$row['ProjectName']}<td><td>{$row['Department']}<td>
<td>{$row['MaxHours']}<td><td>{$row['StartDate']}<td><td>{$row['EndDate']}</tr><td>";
	
}
echo "</table>";


?>