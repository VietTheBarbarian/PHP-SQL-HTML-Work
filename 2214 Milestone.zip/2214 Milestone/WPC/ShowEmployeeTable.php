	<a href="form.html"> link to back to form </a>
	<a href="report.html"> link to back to report </a>

<?php

$DBConnect = mysqli_connect('127.0.0.1:3306', 'root','', 'wpc');
if (!$DBConnect){  
die('Could not connect; ' . mysqli_connect_error());
// investigate the function, die( ) 
 }
$sql = "SELECT * FROM EMPLOYEE";
$result = mysqli_query($DBConnect,$sql);

echo "<table border= '1'>";
echo "<tr><td>EmployeeNumber</td><td>FirstName<td><td>LastName<td><td>Department<td>
<td>Position<td><td>Supervisor<td><td>OfficePhone<td><td>EmailAddress</tr><td>";



while($row= mysqli_fetch_assoc($result)){
	echo "<tr><td>{$row['EmployeeNumber']}</td><td>{$row['FirstName']}<td><td>{$row['LastName']}<td>
<td>{$row['Department']}<td><td>{$row['Position']}<td><td>{$row['Supervisor']}<td><td>{$row['OfficePhone']}<td><td>{$row['EmailAddress']}</tr><td>";
	
}
echo "</table>";


?>