<html>
	<a href="ShowEmployeeTable.php"> link to back to see table </a>
		<a href="form.html"> link to back to form </a>

</html>



<?php
$DBConnect = mysqli_connect('127.0.0.1:3306', 'root','', 'wpc');
if (!$DBConnect){  
die('Could not connect; ' . mysqli_connect_error());
// investigate the function, die( ) 
 }



if(empty($_POST['newvalue']) == false &&  $_POST['change'] == 'FirstName' ) {
$FirstName = $_POST['newvalue'];
 $sql = "UPDATE employee SET ".$_POST['change']."='".$_POST['newvalue']."' WHERE EmployeeNumber=".$_POST['id'].";";
 mysqli_query($DBConnect, $sql);
 echo 'FirstName added';

 echo "  ".$sql;
}

else if(empty($_POST['newvalue']) == false &&  $_POST['change'] == 'LastName' ) {
$lname = $_POST['newvalue'];
echo 'fname added';
 $sql = "UPDATE employee SET ".$_POST['change']."='".$_POST['newvalue']."' WHERE EmployeeNumber=".$_POST['id'].";";
echo "  ".$sql;
}

else if(empty($_POST['newvalue']) == false &&  $_POST['change'] == 'Department' ) {
$Department = $_POST['newvalue'];
echo 'Department added';
 $sql = "UPDATE employee SET ".$_POST['change']."='".$_POST['newvalue']."' WHERE EmployeeNumber=".$_POST['id'].";";
echo "  ".$sql;
}

else if(empty($_POST['newvalue']) == false &&  $_POST['change'] == 'Position' ) {
$Position = $_POST['newvalue'];
echo 'Position added';
 $sql = "UPDATE employee SET ".$_POST['change']."='".$_POST['newvalue']."' WHERE EmployeeNumber=".$_POST['id'].";";
echo "  ".$sql;
}

else if(empty($_POST['newvalue']) == false &&  $_POST['change'] == 'Supervisor' ) {
$Supervisor = $_POST['newvalue'];
echo 'Supervisor added';
 $sql = "UPDATE employee SET ".$_POST['change']."='".$_POST['newvalue']."' WHERE EmployeeNumber=".$_POST['id'].";";
echo "  ".$sql;
}

else if(empty($_POST['newvalue']) == false &&  $_POST['change'] == 'OfficePhone' && filter_var($_POST['newvalue'], FILTER_VALIDATE_INT) == true) {
$OfficePhone = $_POST['newvalue'];
echo 'OfficePhone added';
 $sql = "UPDATE employee SET ".$_POST['change']."='".$_POST['newvalue']."' WHERE EmployeeNumber=".$_POST['id'].";";
echo "  ".$sql;
}



else if(empty($_POST['newvalue']) == false &&  $_POST['change'] == 'EmailAddress' && filter_var($_POST['newvalue'], FILTER_VALIDATE_EMAIL) == true ) {
$email = $_POST['newvalue'];
 $sql = "UPDATE employee SET ".$_POST['change']."='".$_POST['newvalue']."' WHERE EmployeeNumber=".$_POST['id'].";";
 echo "  ".$sql;
echo 'That a valid email';
}

else{
	
	echo "Missing information in ".$_POST['change'];
	echo ". If OfficePhone it must be in number. Must be email format for email.";
}




?>
