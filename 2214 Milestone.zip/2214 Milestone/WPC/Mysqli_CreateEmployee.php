<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Employee Created</title>
		<a href="ShowEmployeeTable.php"> Click to show the employee table in the database</a> <br>

<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
</head>
<body>
<?php


if (empty($_POST['fname']) || empty($_POST['lname']))
     echo "<p>Use back button to complete from</P>";
else {
     $DBConnect = @mysqli_connect('127.0.0.1:3306', 'root','','wpc');
     if ($DBConnect === FALSE)
          echo "<p>Unable to connect to the database server.</p>"
               . "<p>Error code " . mysqli_connect_errno()
               . ": " . mysqli_connect_error() . "</p>";
     else {
          $DBName = "wpc";
          if (@mysqli_select_db($DBConnect, $DBName)) {
               
		  $TableName = "employee";
		  
     	 $sql = "INSERT INTO employee (FirstName, LastName, Department, Position, Supervisor, OfficePhone, EmailAddress) VALUES('".$_POST['fname']."', '".$_POST['lname']."', '".$_POST['dep']."', '".$_POST['pos']."', '".$_POST['sup']."', '".$_POST['offPh']."', '".$_POST['email']."');";;      

            $QueryResult = @mysqli_query($DBConnect, $sql);
               if ($QueryResult === FALSE)
                    echo "<p>Unable to add employee.</p>"
                       . "<p>Error code " . mysqli_errno($DBConnect)
                       . ": " . mysqli_error($DBConnect) . "</p>";
               else
                    echo "<h1>Successfully added</h1>";
          }
          mysqli_close($DBConnect);
     }
}
?>
</body>
</html>

