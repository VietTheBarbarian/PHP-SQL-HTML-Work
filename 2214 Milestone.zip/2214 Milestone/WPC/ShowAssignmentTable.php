	<a href="form.html"> link to back to form </a>
	<a href="report.html"> link to back to report </a>


<?php

$DBConnect = mysqli_connect('127.0.0.1:3306', 'root','', 'wpc');
if (!$DBConnect){  
die('Could not connect; ' . mysqli_connect_error());
// investigate the function, die( ) 
 }
$sql = "SELECT * FROM Assignment";
$result = mysqli_query($DBConnect,$sql);

echo "<table border= '1'>";
echo "<tr><td>ProjectID</td><td>EmployeeNumber<td><td>HoursWorked</tr><td>";



while($row= mysqli_fetch_assoc($result)){
	echo "<tr><td>{$row['ProjectID']}</td><td>{$row['EmployeeNumber']}<td><td>{$row['HoursWorked']}</tr><td>";
	
}
echo "</table>";


?>