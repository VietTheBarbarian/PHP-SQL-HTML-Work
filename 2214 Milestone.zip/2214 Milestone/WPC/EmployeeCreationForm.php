<!DOCTYPE html>
<html>
	<head>
		<style>.error {color: #FF0000;} </style>
		<title> email validation practice </title>
	</head>
	<body>
<?php
// define variables and set to empty values
$fnameErr = $lnameErr = $emailErr = $offPhErr = $posErr = "";
$fname = $lname =$email = $offPh = $pos = $sup = $dep = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["fname"])) {
    $fnameErr = "First Name is required";
  } else {
    $fname = test_input($_POST["fname"]);
    // check if name only contains letters and whitespace
    if (!preg_match("/^[a-zA-Z ]*$/",$fname)) {
      $fnameErr = "Only letters and white space allowed";
    }
  }
  if (empty($_POST["lname"])) {
    $lnameErr = "Last Name is required";
  } else {
    $lname = test_input($_POST["lname"]);
    // check if name only contains letters and whitespace
    if (!preg_match("/^[a-zA-Z ]*$/",$lname)) {
      $lnameErr = "Only letters and white space allowed";
    }
  }
   if (empty($_POST["dep"])) {
    $comment = "";
  } else {
    $comment = test_input($_POST["dep"]);
  }
  
   if (empty($_POST["pos"])) {
    $posErr = "Position is required";
  } else {
    $comment = test_input($_POST["pos"]);
  }
  if (empty($_POST["sup"])) {
    $comment = "";
  } else {
    $comment = test_input($_POST["sup"]);
  }
  
  if (empty($_POST["email"])) {
    $emailErr = "Email is required";
  } else {
    $email = test_input($_POST["email"]);
    // check if e-mail address is well-formed
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $emailErr = "Invalid email format";
    }
  }
  if (empty($_POST["offPh"])) {
    $offPhErr = "";
  } else {
    $offPh = test_input($_POST["offPh"]);
    // check if name only contains letters and whitespace
    if(!preg_match("/^[0-9]{3}-[0-9]{3}-[0-9]{4}$/", $offPh)) {
      $offPhErr = "INVALID (Valid Format: 000-000-0000)";
    }
  }

 
}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>

<h2>PHP Form Validation Example</h2>
<p><span class="error">* required field</span></p>
 <form action="Mysqli_CreateEmployee.php" method="post"> 
  First Name: <input type="text" name="fname" value="<?php echo $fname;?>">
  <span class="error">* <?php echo $fnameErr;?></span>
  <br><br>
  Last Name: <input type="text" name="lname" value="<?php echo $lname;?>">
  <span class="error">* <?php echo $lnameErr;?></span>
  <br><br>
  Department:
	  <select name="dep">
		<option value="Human Resources">Human Resources</option>
		<option value="Legal">Legal</option>
		<option value="Administration">Administration</option>
		<option value="Finance">Finance</option>
		<option value="Accounting">Accounting</option>
		<option value="Sales and Marketing">Sales and Marketing</option>
		<option value="InfoSystems">InfoSystems</option>
		<option value="Research and Development">Research and Development</option>
		<option value="Production">Production</option>
	  </select>
  <br><br>
  Position: <input type="text" name="pos" value="<?php echo $pos;?>">
  <span class="error">* <?php echo $posErr;?></span><br><br>
  Supervisor: <input type="text" name="sup" value="<?php echo $sup;?>">
  <br><br>
  Office Phone: <input type="text" name="offPh" value="<?php echo $offPh;?>">
  <span class="error"> <?php echo $offPhErr;?></span>
  <br><br>
  E-mail: <input type="text" name="email" value="<?php echo $email;?>">
  <span class="error">* <?php echo $emailErr;?></span>
  <br><br>
  
  <p><input type="reset" value="Clear Form" />&nbsp; &nbsp;
     <input type="submit" name="Submit" value="Send Form" />
  </form>


	</body>
</html>