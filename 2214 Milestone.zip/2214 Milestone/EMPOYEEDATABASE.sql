
DROP TABLE IF EXISTS ASSIGNMENT;
DROP TABLE IF EXISTS EMPLOYEE;
DROP TABLE IF EXISTS PROJECT;
DROP TABLE IF EXISTS DEPARTMENT;
COMMIT;



CREATE TABLE DEPARTMENT (
                DepartmentName CHAR(35) NOT NULL,
                BudgetCode CHAR(30) NOT NULL,
                OfficeNumber CHAR(15) NOT NULL,
				DepartmentPhone CHAR(12) NOT NULL,

                CONSTRAINT DEPARTMENT_PK PRIMARY KEY (DepartmentName)
);


CREATE TABLE PROJECT (
                ProjectID Int NOT NULL,
                ProjectName CHAR(50) NOT NULL,
                Department CHAR(35) NOT NULL,
                MaxHours NUMERIC (5,1) NOT NULL DEFAULT 100,
                StartDate DATE,
                EndDate DATE,
                CONSTRAINT ProjectID PRIMARY KEY (ProjectID),
                CONSTRAINT PROJ_DEPART_FK FOREIGN KEY(Department)
                REFERENCES DEPARTMENT(DepartmentName)
                ON UPDATE CASCADE
);


CREATE TABLE EMPLOYEE (
                EmployeeNumber int NOT NULL AUTO_INCREMENT, 
                FirstName CHAR(25) NOT NULL,
                LastName CHAR(25) NOT NULL,
                Department CHAR(35) NOT NULL DEFAULT 'Human Resource',
                Position CHAR(35),
                Supervisor int ,
                OfficePhone CHAR(12),
                EmailAddress VARCHAR(100) NOT NULL UNIQUE,
				CONSTRAINT EMPLOYEE_PK PRIMARY KEY(EmployeeNumber),
                CONSTRAINT EMP_DEPART_FK FOREIGN KEY(Department) 
                REFERENCES DEPARTMENT(DepartmentName) 
                ON UPDATE CASCADE, 
                CONSTRAINT EMP_SUPER_FK FOREIGN KEY(Supervisor) REFERENCES EMPLOYEE(EmployeeNumber) 
);


CREATE TABLE ASSIGNMENT (
                ProjectID int NOT NULL,
                EmployeeNumber int NOT NULL,
                HoursWorked NUMERIC (5,1),
                CONSTRAINT ASSIGNMENT_Pk PRIMARY KEY (ProjectID, EmployeeNumber),
				CONSTRAINT ASSIGN_PROJ_FK FOREIGN KEY(PROJECTID)
				REFERENCES PROJECT(ProjectID)
				ON UPDATE NO ACTION
				ON DELETE CASCADE,
				CONSTRAINT ASSIGN_EMP_FK FOREIGN KEY(EmployeeNumber)
				REFERENCES EMPLOYEE(EmployeeNumber)
				ON UPDATE NO ACTION
				ON DELETE NO ACTION





);


